# more-transformers
My own list of "extra" transformers in scikit-learn pipelines
